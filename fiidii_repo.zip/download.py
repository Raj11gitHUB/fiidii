import os

dow_path = "./fiidii"
os.makedirs(dow_path, exist_ok=True)

print("Download script running... (Add your download code here)")